static void show_credits()
{
   printf("\n***  "PACKAGE_NAME" "PACKAGE_VERSION"  ***\n");
   printf(" cpuminer with multi algo support android CPUs\n");
   printf(" Bitcoin (BTC) donate tpruvot: 1FhDPLPpw18X4srecguG3MxJYe4a1JsZnd\n\n");
   printf(" Yenten (YTN) donate giauvn: YcFr9Byhdth8eYnYV8fMdCBvrLXrvA4w7N\n\n");
   printf(" Bitcoin (BTC) donate giauvn: 1NTFG5XRcRwWW6X8TUZa7t5ZETW1AU9iWv\n\n");	
}