<php?>
  phpinfo()
  <?php>
